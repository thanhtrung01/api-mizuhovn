const accessCors = [
    { url: '/api/v1/auth/login', method: ['POST'] }
]
module.exports = accessCors;